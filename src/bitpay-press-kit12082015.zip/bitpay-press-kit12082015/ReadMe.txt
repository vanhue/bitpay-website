BitPay Press Kit
----------------
Updated: May 7, 2015

BitPay provides powerful integrations for businesses to add bitcoin as a payment method. With BitPay, businesses can accept bitcoin and get paid in US Dollars, Euros, GBP, CAD, and more, straight to a bank account.

Over 60,000 businesses and organizations including Microsoft, Adyen, Gyft, Shopify, TigerDirect, and Virgin Galactic trust BitPay to enable bitcoin payments.

------------------------------

* Logo Guidelines

Our logo is a word mark derived from the Ubuntu font— the the first typeface associated with bitcoin.

We prefer you use the white logo on a blue (or dark) background whenever possible, followed by the blue logo on a white (or light) background. Please be sure to include adequate spacing around the logo and resist the temptation to embellish the logo with any additional effects, treatments, or colors.

------------------------------

* Capitalization

BitPay is written with the “B” and “P” capitalized to distinguish BitPay (our company) from bitcoin (the currency).

CORRECT: BitPay
INCORRECT: Bitpay, bitPay, bit-pay, bit pay

------------------------------

* Contact information

Email: media@bitpay.com
bitpay.com
